#include"gomoku.h"


void mygomokuAI::clear()
{
    for(int i=1;i<=15;i++) for(int j=1;j<=15;j++) board[i][j]=0;
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
}

Point mygomokuAI::step(Point p)
{
    int x=p.x,y=p.y,maxn=-1000000000,s=0,opp=3-me;
    board[x][y]=opp;
    Point q;
    vector<Point> ans;
    for(int i=1;i<=15;i++) for(int j=1;j<=15;j++) if(!board[i][j])
    {
       q.x=i;q.y=j;
       s=calval(q,me);
       if(s==maxn) ans.push_back(q);
       if(s>maxn){maxn=s;ans.clear();ans.push_back(q);}
    }

    for(int i=1;i<=15;i++) for(int j=1;j<=15;j++) if(!board[i][j])
    {
        q.x=i;q.y=j;
        s=calval(q,opp);
        if(s==maxn) ans.push_back(q);
        if(s>maxn){maxn=s;ans.clear();ans.push_back(q);}
    }
    /*for(int i=1;i<=15;i++) for(int j=1;j<=15;j++) if(!board[i][j])
    {
       q.x=i;q.y=j;
       s=searching(q,me,1);
       if(s==maxn) ans.push_back(q);
       if(s>maxn){maxn=s;ans.clear();ans.push_back(q);}
    }*/
    /*qDebug("%d %d  %d\n",ans[0].x,ans[0].y,maxn);*/
    s=qrand()%ans.size();
    q=ans[s];ans.clear();ans.shrink_to_fit();
    board[q.x][q.y]=me;

    return q;
}

bool mygomokuAI::legal(Point p)
{
    return (p.x>0&&p.y>0&&p.x<16&&p.y<16);
}

int mygomokuAI::which(Point p)
{
    if(!legal(p)) return 0;
    return board[p.x][p.y];
}

int mygomokuAI::hmy(Point p, int f, int who)
{
    int cnt=0;
    while(legal(p+fx[f]*(cnt+1)))
    {
        if(which(p+fx[f]*(cnt+1))!=who) break;
        cnt++;
    }
    return cnt;
}

bool mygomokuAI::checkfive(Point p,int who)
{
    bool f=0;
    for(int i=0;i<5;i++)
    {
        if(hmy(p,i,who)+hmy(p,i+4,who)>3){f=1;break;}
    }
    return f;
}

bool mygomokuAI::checklivefour(Point p, int who)
{
    bool f=0;
    int l,r;
    for(int i=0;i<5;i++)
    {
       l=hmy(p,i,who);r=hmy(p,i+4,who);
       if(l+r>2&&which(p+fx[i]*(l+1))==0&&which(p+fx[i+4]*(r+1))==0){f=1;break;}
    }
    return f;
}

int mygomokuAI::checkdeadfour(Point p, int who)
{
    int cnt=0;
    int l,r,opp=3-who;
    for(int i=0;i<5;i++)
    {
       l=hmy(p,i,who);r=hmy(p,i+4,who);
       if(l+r>2&&((which(p+fx[i]*(l+1))==opp&&which(p+fx[i+4]*(r+1))==0)||(which(p+fx[i]*(l+1))==0&&which(p+fx[i+4]*(r+1))==opp))){cnt++;continue;}
       if(l+r+hmy(p+fx[i]*(l+1),i,who)>3){cnt++;continue;}
       if(l+r+hmy(p+fx[i+4]*(r+1),i+4,who)>3){cnt++;continue;}
    }
    return cnt;
}

int mygomokuAI::checklivethree(Point p, int who)
{
    int cnt=0;
    int l,r,ll,rr;
    for(int i=0;i<5;i++)
    {
       l=hmy(p,i,who);r=hmy(p,i+4,who);
       ll=hmy(p+fx[i]*(l+1),i,who);rr=hmy(p+fx[i+4]*(r+1),i+4,who);
       if(l+r>1&&which(p+fx[i]*(l+1))==0&&which(p+fx[i+4]*(r+1))==0){cnt++;continue;}
       if(ll&&l+r+ll>1&&which(p+fx[i+4]*(r+1))==0&&which(p+fx[i]*(l+ll+2))==0&&which(p+fx[i]*(l+1))==0){cnt++;continue;}
       if(rr&&l+r+rr>1&&which(p+fx[i]*(l+1))==0&&which(p+fx[i+4]*(r+rr+2))==0&&which(p+fx[i+4]*(r+1))==0){cnt++;continue;}
    }
    return cnt;
}

bool mygomokuAI::checkdeadthree(Point p, int who)
{
    bool f=0;
    int l,r,ll,rr,opp=3-who;
    for(int i=0;i<5;i++)
    {
       l=hmy(p,i,who);r=hmy(p,i+4,who);
       ll=hmy(p+fx[i]*(l+1),i,who);rr=hmy(p+fx[i+4]*(r+1),i+4,who);
       if(ll&&l+r+ll>1&&((which(p+fx[i]*(l+1))==0&&which(p+fx[i]*(l+ll+2))==opp&&which(p+fx[i+4]*(r+1))==0)||(which(p+fx[i]*(l+1))==0&&which(p+fx[i]*(l+ll+2))==0&&which(p+fx[i+4]*(r+1))==opp)))
       {f=1;break;}
       if(rr&&l+r+rr>1&&((which(p+fx[i+4]*(r+1))==0&&which(p+fx[i]*(l+1))==opp&&which(p+fx[i+4]*(r+rr+2))==0)||(which(p+fx[i+4]*(r+1))==0&&which(p+fx[i]*(l+1))==0&&which(p+fx[i+4]*(r+rr+2))==opp)))
       {f=1;break;}
       if(l+r>1&&l+r<3&&which(p+fx[i]*(l+2))==opp&&which(p+fx[i+4]*(r+2))==opp&&which(p+fx[i]*(l+1))==0&&which(p+fx[i+4]*(r+1))==0){f=1;break;}
    }
    return f;
}

bool mygomokuAI::checklivetwo(Point p, int who)
{
    bool f=0;
    int l,r,ll,rr;
    for(int i=0;i<5;i++)
    {
       l=hmy(p,i,who);r=hmy(p,i+4,who);
       ll=hmy(p+fx[i]*(l+1),i,who);rr=hmy(p+fx[i+4]*(r+1),i+4,who);
       if(l+r>0&&which(p+fx[i]*(l+1))==0&&which(p+fx[i+4]*(r+1))==0){f=1;break;}
       if(ll&&l+r+ll>0&&which(p+fx[i]*(l+1))==0&&which(p+fx[i]*(l+ll+2))==0&&which(p+fx[i+4]*(r+1))==0){f=1;break;}
       if(ll&&l+r+rr>0&&which(p+fx[i+4]*(r+1))==0&&which(p+fx[i]*(l+1))==0&&which(p+fx[i+4]*(r+rr+2))==0){f=1;break;}
    }
    return f;
}

bool mygomokuAI::checkdeadtwo(Point p, int who)
{
    bool f=0;
    int l,r,ll,rr,opp=3-who;
    for(int i=0;i<5;i++)
    {
       l=hmy(p,i,who);r=hmy(p,i+4,who);
       ll=hmy(p+fx[i]*(l+1),i,who);rr=hmy(p+fx[i+4]*(r+1),i+4,who);
       if(l+r>0&&which(p+fx[i]*(l+1))+which(p+fx[i+4]*(r+1))==opp){f=1;break;}
       if(ll&&l+r+ll>0&&which(p+fx[i]*(l+1))==0&&which(p+fx[i]*(l+ll+2))+which(p+fx[i+4]*(r+1))==opp){f=1;break;}
       if(ll&&l+r+rr>0&&which(p+fx[i+4]*(r+1))==0&&which(p+fx[i]*(l+1))+which(p+fx[i+4]*(r+rr+2))==opp){f=1;break;}
    }
    return f;
}

int mygomokuAI::calval(Point p, int who)
{
    int val=0;
    if(checkfive(p,who)) val+=100000000;
    if(checklivefour(p,who)||checkdeadfour(p,who)>1) val+=2000000;
    if(checklivethree(p,who)>1) val+=1000000;
    if(checklivethree(p,who)==1) val+=100000;
    if(checklivetwo(p,who)) val+=500;
    if(checkdeadfour(p,who)==1){val+=200;if(checklivethree(p,who)) val+=2000000;}
    if(checkdeadthree(p,who)) val+=150;
    if(checkdeadtwo(p,who)) val+=100;
    for(int i=0;i<8;i++) if(legal(p+fx[i])&&which(p+fx[i])!=0) val+=(qrand()%2)*10;
    return val;
}

void mygomokuAI::setlevel(int x)
{
    level=x;
}

void mygomokuAI::setwho(int x)
{
    me=x;
}

int mygomokuAI::searching(Point p, int who, int depth)
{
    int opp=3-who,val;
    board[p.x][p.y]=who;
    if(depth>level)
    {
      Point q;
      val=0;
      int maxn=-1000000000,minn=-1000000000;
      for(int i=1;i<=15;i++) for(int j=1;j<=15;j++) if(board[i][j]==me)
      {
          q.x=i;q.y=j;
          maxn=max(maxn,calval(q,me));
      }
      for(int i=1;i<=15;i++) for(int j=1;j<=15;j++) if(board[i][j]==3-me)
      {
          q.x=i;q.y=j;
          minn=max(minn,calval(q,3-me));
      }
      board[p.x][p.y]=0;val=maxn-minn;
      return val;
    }
    if(who==me) val=-1000000000;else val=1000000000;
    for(int i=1;i<=15;i++) for(int j=1;j<=15;j++) if(!board[i][j]&&(calval({i,j},who)>100||calval({i,j},opp)>100))
    {
        if(who==me) val=max(val,searching({i,j},opp,depth+1));
        else val=min(val,searching({i,j},opp,depth+1));
    }
    board[p.x][p.y]=0;
    return val;
}
